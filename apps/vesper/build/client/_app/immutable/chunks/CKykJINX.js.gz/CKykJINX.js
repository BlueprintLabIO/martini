import{h as p,E as t}from"./B9AHJbAJ.js";import{B as c}from"./Bpvq6DfM.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
